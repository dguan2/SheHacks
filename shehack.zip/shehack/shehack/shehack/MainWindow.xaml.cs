﻿/*
 * Author: Dongming Guan
 * Group member:Dongming, kimia, Sophia,corinamarusca
 * Date: March 16, 2019
 * Purpose:She/hacks, Canada's Largest 12-Hour All-Female Hackathon
 
 */

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace shehack
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ObservableCollection<Category> categoryList;

        public MainWindow()
        {
            InitializeComponent();
            categoryList = new ObservableCollection<Category>();
            this.DataContext = categoryList;
        }
        private void Btn1_Click(object sender, RoutedEventArgs e)
        {
            Category p = new Category();
            p.firstCategory = tb1.Text;
            p.secondCategory = tb2.Text;
            p.thirdCategory = tb3.Text;
            p.lastCategory = tb4.Text;
            categoryList.Add(p);
            //lb1.Items.Add(p);
        }

        private void Btn2_Click(object sender, RoutedEventArgs e)
        {
            categoryList.RemoveAt(lb1.SelectedIndex);
            //lb1.Items.RemoveAt(lb1.SelectedIndex);

        }

        private void Btn3Food_Click(object sender, RoutedEventArgs e)
        {
        
            var fmainWindow = new FoodMainWindow();
            fmainWindow.Show();
            this.Close();
        }

        private void Btn4Social_Click(object sender, RoutedEventArgs e)
        {
          
            var smainWindow = new SocialMainWindow();
            smainWindow.Show();
           this.Close();
        }

        private void Btn5School_Click(object sender, RoutedEventArgs e)
        {
           
            var schmainWindow = new SchoolMainWindow();
            schmainWindow.Show();
            this.Close();
        }

        private void Btn6Gift_Click(object sender, RoutedEventArgs e)
        {
         
            var gmainWindow = new GiftMainWindow();
            gmainWindow.Show();
           this.Close();
        }
    }
}
