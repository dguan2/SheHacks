﻿


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace shehack
{
    class Category
    {
        private string firstCategory_;
        public string firstCategory
        {
            get { return firstCategory_; }
            // add the code to the setters so that the PropertyChangedEventArgs 
            // are invoked for property changes
            set
            {

                if (firstCategory_ != value)
                {
                    firstCategory_ = value;
                    PropertyChanged?.Invoke(this,
                        new PropertyChangedEventArgs("firstCategory"));
                }
            }
        }

        private string secondCategory_;
        public string secondCategory
        {
            get { return secondCategory_; }
            // add the code to the setters so that the PropertyChangedEventArgs 
            // are invoked for property changes
            set
            {

                if (secondCategory_ != value)
                {
                    secondCategory_ = value;
                    PropertyChanged?.Invoke(this,
                        new PropertyChangedEventArgs("secondCategory"));
                }
            }
        }
        private string thirdCategory_;
        public string thirdCategory
        {
            get { return thirdCategory_; }
            // add the code to the setters so that the PropertyChangedEventArgs 
            // are invoked for property changes
            set
            {

                if (thirdCategory_ != value)
                {
                    thirdCategory_ = value;
                    PropertyChanged?.Invoke(this,
                        new PropertyChangedEventArgs("thirdCategory"));
                }
            }
        }


        private string lastCategory_;

        public string lastCategory
        {
            get { return lastCategory_; }
            set
            {

                if (lastCategory_ != value)
                {
                    lastCategory_ = value;
                    PropertyChanged?.Invoke(this,
                        new PropertyChangedEventArgs("lastCategory"));
                }
            }
        }
        // override the ToString because that is what is shown in the listBox
        public override string ToString()
        {
            return firstCategory + " " + secondCategory + " " + thirdCategory + " "+ lastCategory;
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
