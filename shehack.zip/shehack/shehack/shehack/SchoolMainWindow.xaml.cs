﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace shehack
{
    /// <summary>
    /// Interaction logic for SchoolMainWindow.xaml
    /// </summary>
    public partial class SchoolMainWindow : Window
    {
        string sstr1;
        public SchoolMainWindow()
        {
            InitializeComponent();
            schoolPage();
        }

        public void schoolPage()
        {
            //var mainWindow1 = new MainWindow();
            //sstr1 = mainWindow1.tb4.Text;
            string s = "There are " + "some" + " School.";
            txt2School.Text = s;

        }
        private void BtnSchoolReturn_Click(object sender, RoutedEventArgs e)
        {
            
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();

        }
    }
}
