﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace shehack
{
    /// <summary>
    /// Interaction logic for FoodMainWindow.xaml
    /// </summary>
    public partial class FoodMainWindow : Window
    {
        string fstr1;
        public FoodMainWindow()
        {
            InitializeComponent();
            foodPage();
        }

        public void foodPage()
        {
            //var mainWindow1 = new MainWindow();
            //fstr1 = mainWindow1.tb4.Text;
            string s = "There are " + "some" + " food.";
            txt2Food.Text = s;

        }

        private void BtnFoodReturn_Click(object sender, RoutedEventArgs e)
        {
           
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
